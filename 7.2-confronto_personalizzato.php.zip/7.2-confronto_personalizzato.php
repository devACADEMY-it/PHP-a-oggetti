<!--

	PHP a oggetti
	Confronti personalizzati

	Disponibile su devACADEMY.it

-->

<?php
	class Candidato
	{
		public $java;
		public $php;

		function __construct($j, $p)
		{
			$this->java=$j;
			$this->php=$p;
		}

		private function media()
		{
			return ($this->java+$this->php)/2;
		}

		function uguale($candidato)
		{
			return (abs($this->media()-$candidato->media())<=1);
		}

	}

	$a1=new Candidato(8, 9);
	$a2=new Candidato(8, 7);
	$a3=new Candidato(7, 7);

	if ($a1->uguale($a2))
		echo '$a1 e $a2 si equivalgono <br>';
	else
		echo '$a1 e $a2 NON si equivalgono <br>';

	if ($a1->uguale($a3))
		echo '$a1 e $a3 si equivalgono <br>';
	else
		echo '$a1 e $a3 NON si equivalgono <br>';

?>