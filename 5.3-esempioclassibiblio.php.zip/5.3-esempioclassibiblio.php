﻿<!--

	PHP a oggetti
	Esempio: classi per una biblioteca moderna

	Disponibile su devACADEMY.it

-->

<?php

	class Autore
	{
		private $nome;
		private $cognome;

		function __construct($n, $c)
		{
			$this->nome=$n;
			$this->cognome=$c;
		}
	}

	class Opera
	{
		protected $titolo;
		protected $autore;

		function __construct($titolo)
		{
			$this->titolo=$titolo;
		}

		function aggiungiAutore($autore)
		{
			if (is_a($autore, 'Autore'))
			{
				$this->autore=$autore;
				return TRUE;
			}
			else
				return FALSE;
		}
	}

	class Libro extends Opera
	{
		private $anonimo=FALSE;

		function aggiungiAutore($autore)
		{
			if (parent::aggiungiAutore($autore))
			{
				$this->anonimo=FALSE;
			}
		}

		function autoreAnonimo()
		{
			$this->anonimo=TRUE;
			$this->autore=NULL;
		}
	}

	class CD extends Opera
	{
		private $num_tracce=0;

		function __construct($titolo, $nt)
		{
			parent::__construct($titolo);
			$this->num_tracce=$nt;
		}
	}

	$manzoni=new Autore("Alessandro", "Manzoni");
	$libro=new Libro("Promessi sposi");
	$libro->aggiungiAutore($manzoni);

	$album=new CD("Il mio canto libero", 8);
	$album->aggiungiAutore(new Autore("Lucio", "Battisti"));

	var_dump($libro);
	var_dump($album);

?>