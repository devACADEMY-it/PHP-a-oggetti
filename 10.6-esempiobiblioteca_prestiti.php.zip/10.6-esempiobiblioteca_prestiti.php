﻿<!--

	PHP a oggetti
	Esempio: utenti e prestiti nella biblioteca

	Disponibile su devACADEMY.it

-->

<?php

	class Prestito
	{
		private $utente;
		private $opera;
		private $scadenza;

		function __construct($u, $o)
		{
			$this->utente=$u;
			$this->opera=$o;
			$this->scadenza=$o->calcolaScadenza();
		}

		function stampa()
		{
			return $this->opera->getTitolo().
					" concessa in prestito a ".
					$this->utente->getNomeCompleto().
					" fino al ".
					date("d-M-Y", $this->scadenza);
		}
	}

	class Biblioteca
	{
		private $utenti;
		private $catalogo;
		private $nome;
		private $prestiti;

		function __construct($n)
		{
			$this->nome=$n;
		}

		function aggiungiUtente($u)
		{
			if (is_a($u, 'Utente'))
			{
				$this->utenti[]=$u;
				return TRUE;
			}
			else
				return FALSE;
		}

		function aggiungiOpera($o)
		{
			if (is_a($o, 'Opera'))
			{
				$this->catalogo[]=$o;
				return TRUE;
			}
			else
				return FALSE;
		}

		function creaPrestito($u, $o)
		{
			$p=new Prestito($u, $o);
			$this->prestiti[]=$p;
			return $p;
		}


	}

	class Persona
	{
		protected $nome;
		protected $cognome;

		function __construct($n, $c)
		{
			$this->nome=$n;
			$this->cognome=$c;
		}

		function getNomeCompleto()
		{
			return "$this->nome $this->cognome";
		}
	}

	class Autore extends Persona
	{}

	class Utente extends Persona
	{
		private $numero_tessera;
		private static $numero_utenti;

		function __construct($n, $c)
		{
			parent::__construct($n, $c);
			self::$numero_utenti++;
			$this->creaNumeroTessera();
		}

		private function creaNumeroTessera()
		{
			$this->numero_tessera= substr($this->nome,0,2).
								substr($this->cognome,0,2).
								sprintf("%02d", self::$numero_utenti);
		}
	}

	abstract class Opera
	{
		protected $titolo;
		protected $autore;

		function __construct($titolo)
		{
			$this->titolo=$titolo;
		}

		function aggiungiAutore($autore)
		{
			if (is_a($autore, 'Autore'))
			{
				$this->autore=$autore;
				return TRUE;
			}
			else
				return FALSE;
		}

		function getTitolo()
		{
			return $this->titolo;
		}

		abstract function calcolaScadenza();

	}

	class Libro extends Opera
	{
		private $anonimo=FALSE;

		function aggiungiAutore($autore)
		{
			if (parent::aggiungiAutore($autore))
			{
				$this->anonimo=FALSE;
			}
		}

		function autoreAnonimo()
		{
			$this->anonimo=TRUE;
			$this->autore=NULL;
		}

		function calcolaScadenza()
		{
			return strtotime("+4 week");
		}
	}

	class CD extends Opera
	{
		private $num_tracce=0;

		function __construct($titolo, $nt)
		{
			parent::__construct($titolo);
			$this->num_tracce=$nt;
		}

		function calcolaScadenza()
		{
			return strtotime("+2 week");
		}
	}

	$manzoni=new Autore("Alessandro", "Manzoni");
	$libro=new Libro("Promessi sposi");
	$libro->aggiungiAutore($manzoni);

	$album=new CD("Il mio canto libero", 8);
	$album->aggiungiAutore(new Autore("Lucio", "Battisti"));

	$u=new Utente("Massimo", "Rossi");

	$b=new Biblioteca("Biblioteca Civica Lucio Battisti");
	$b->aggiungiUtente($u);
	$b->aggiungiOpera($libro);
	$b->aggiungiOpera($album);

	$p=$b->creaPrestito($u, $libro);

	var_dump($b);

	echo $p->stampa();

?>