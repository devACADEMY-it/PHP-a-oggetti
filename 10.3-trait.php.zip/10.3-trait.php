<!--

	PHP a oggetti
	I trait

	Disponibile su devACADEMY.it

-->

<?php

trait MioComportamento
{
	function dettagli()
	{
		echo "questo codice viene da un trait <br>";
	}
}

class MiaClasse
{
	use MioComportamento;
}

$m=new MiaClasse();
$m->dettagli();

?>