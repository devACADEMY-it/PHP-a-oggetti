<!--

	PHP a oggetti
	Accesso alla classe base

	Disponibile su devACADEMY.it

-->

<?php

	class Persona
	{
		private $nome;
		private $cognome;

		private function inizializza($n, $c)
		{
			$this->nome=$n;
			$this->cognome=$c;
		}
	}

	class Studente extends Persona
	{
		public $facolta;
	}

	$studente=new Studente();
	//$studente->nome="Stefano";
	//$studente->cognome="Bianchi";
	$studente->facolta="medicina";

	$studente->inizializza("Stefano", "Bianchi");

	var_dump($studente);

?>