<!--

	PHP a oggetti
	Attributi static

	Disponibile su devACADEMY.it

-->

<?php

	class Account
	{
		private $username;
		private $password;
		private static $count;
		const PREFIX="user_";

		function __construct($u, $p="12345")
		{
			$this->username=self::PREFIX.$u;
			$this->password=$p;

			self::$count++;
			printf("Creato $this->username: account n. %d <br>", self::$count);
		}
	}

	$a=new Account("pippo");
	$b=new Account("topolino");
	$c=new Account("pluto");
	$d=new Account("paperino");
	$e=new Account("paperone");

?>