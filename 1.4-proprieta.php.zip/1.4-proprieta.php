<!--

	PHP a oggetti
	Proprietà delle classi

	Disponibile su devACADEMY.it

-->

<?php

	class Persona
	{
		public $nome;
		public $cognome;
		public $eta;

		public $recapitiTel=array();
	}

	$persona=new Persona();
	$persona->nome="Nino";
	$persona->cognome="Rossi";
	$persona->eta=25;

	$persona->recapitiTel[]="3345896321";
	$persona->recapitiTel[]="3298742511";
	$persona->recapitiTel[]="3497853662";

	$persona->email="nino.ro@gmail.com";

	var_dump($persona);

	printf("$persona->nome $persona->cognome ha %d recapiti telefonici",
		count($persona->recapitiTel));

?>