<!--

	PHP a oggetti
	Classi astratte

	Disponibile su devACADEMY.it

-->

<?php

abstract class Poligono
{
	abstract function calcolaArea();
}

class Rettangolo extends Poligono
{
	private $lato1;
	private $lato2;

	function __construct($l1, $l2)
	{
		$this->lato1=$l1;
		$this->lato2=$l2;
	}

	function calcolaArea()
	{
		return $this->lato1*$this->lato2;
	}
}

class Triangolo extends Poligono
{
	private $base;
	private $altezza;

	function __construct($l1, $l2)
	{
		$this->base=$l1;
		$this->altezza=$l2;
	}

	function calcolaArea()
	{
		return $this->base*$this->altezza/2;
	}
}

$t=new Triangolo(4,6);
$r=new Rettangolo(4,6);

/*echo $t->calcolaArea()." <br>";
echo $r->calcolaArea()." <br>";*/

$poligoni[]=$t;
$poligoni[]=$r;

foreach($poligoni as $f)
	echo "Area dell'oggetto di classe ".get_class($f)." = ".$f->calcolaArea()."<br>";

?>