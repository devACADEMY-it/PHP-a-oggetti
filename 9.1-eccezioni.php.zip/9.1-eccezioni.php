<!--

	PHP a oggetti
	Gestire gli errori con le eccezioni

	Disponibile su devACADEMY.it

-->

<?php

	$valore=2;
	try
	{
		if ($valore<-5 || $valore>5)
			throw new Exception();
		echo "OK $valore accettato <br>";
	}
	catch(Exception $e)
	{
		echo "KO $valore non valido <br>";
	}
	finally
	{
		echo "Questo lo stampiamo comunque... <br>";
	}

?>