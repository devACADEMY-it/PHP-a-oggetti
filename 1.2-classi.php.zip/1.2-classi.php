<!--

	PHP a oggetti
	Definizione di una classe

	Disponibile su devACADEMY.it

-->

<?php
	class Persona
	{
		public $nome;
		public $cognome;
	}

	$persona=new Persona();
	$persona->nome="Alessio";
	$persona->cognome="Rossi";

	echo $persona->nome;
	echo "<br>";
	echo "$persona->nome $persona->cognome";
?>