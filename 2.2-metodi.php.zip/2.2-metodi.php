<!--

	PHP a oggetti
	I metodi

	Disponibile su devACADEMY.it

-->

<?php

	class Persona
	{
		public $nome;
		public $cognome;
		public $eta;

		function dettagli()
		{
			return "$this->nome $this->cognome di anni $this->eta";
		}

		function inizializza($nome, $cognome, $eta)
		{
			$this->nome=$nome;
			$this->cognome=$cognome;
			$this->eta=$eta;
		}

	}

	$persona=new Persona();
	$persona->nome="Nino";
	$persona->cognome="Rossi";
	$persona->eta=25;

	echo $persona->dettagli();

	var_dump($persona);

	$persona->inizializza("Alessio", "Neri", 19);

	var_dump($persona);

?>