<!--

	PHP a oggetti
	Approfondimento sulle eccezioni

	Disponibile su devACADEMY.it

-->

<?php

class MiaEccezione extends Exception
{
	function __construct($v)
	{
		$this->message="Alle ".date('H:i:s')." inserito $v";
	}
}

$valore=34;
try
{
	if ($valore<-5 || $valore>5)
		throw new MiaEccezione($valore);
	echo "OK $valore accettato <br>";
}
catch(MiaEccezione $e)
{
	echo $e;
	//echo "KO $valore non valido <br>";
}

?>