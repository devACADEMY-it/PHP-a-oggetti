<!--

	PHP a oggetti
	Type hinting

	Disponibile su devACADEMY.it

-->

<?php

class Persona
{
	function dettagli()
	{
		echo "oggetto Persona <br>";
	}
}

function stampa(Persona $p)
{
	$p->dettagli();
}

try
{
	stampa(new Persona());
	stampa(14);
}
catch(Error $e)
{
	echo "non abbiamo passato un oggetto Persona <br>";
}

?>