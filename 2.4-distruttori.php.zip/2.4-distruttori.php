<!--

	PHP a oggetti
	Distruzione di un oggetto

	Disponibile su devACADEMY.it

-->

<?php

	class Persona
	{
		public $nome;
		public $cognome;
		public $eta;

		function __construct($n, $c, $e)
		{
			echo "ORA nasce l'oggetto $n $c <br>";
			$this->nome=$n;
			$this->cognome=$c;
			$this->eta=$e;
		}

		function __destruct()
		{
			echo "*** $this->nome $this->cognome viene distrutto *** <br>";
		}


	}

	$persona=new Persona("Nino", "Rossi", 25);
	$persona=new Persona("Alessia", "Verdi", 22);

	var_dump($persona);

?>