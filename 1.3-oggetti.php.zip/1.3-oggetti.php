<!--

	PHP a oggetti
	Usare gli oggetti

	Disponibile su devACADEMY.it

-->

<?php

	class Persona
	{
		public $nome;
		public $cognome;
		public $eta;
	}

	$persona=new Persona();
	$persona->nome="Nino";
	$persona->cognome="Rossi";
	$persona->eta=29;

	$altrapersona=new Persona();
	$altrapersona->nome="Alessia";
	$altrapersona->cognome="Verdi";
	$altrapersona->eta=29;

	if ($persona->eta > $altrapersona->eta)
		echo "$persona->nome maggiore di $altrapersona->nome";
	elseif ($persona->eta < $altrapersona->eta)
		echo "$persona->nome minore di $altrapersona->nome";
	else
		echo "$persona->nome e $altrapersona->nome sono coetanei";

?>