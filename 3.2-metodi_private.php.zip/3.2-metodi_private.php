<!--

	PHP a oggetti
	Metodi privati

	Disponibile su devACADEMY.it

-->

<?php

	class Persona
	{
		private $nome;

		function setNome($n)
		{
			if ($this->controllo($n))
			{
				$this->nome=$n;
				echo "nome accettato";
			}
			else
				echo "nome riufiutato";
		}

		private function controllo($n)
		{
			return preg_match("/^[A-Z][a-z]+(\s[A-Z][a-z]+)*$/", $n);
		}
	}

	$tizio= new Persona();
	$tizio->setNome("Paolo Emilio");

	var_dump($tizio);

	$tizio->controllo("Paolo Emilio");

?>