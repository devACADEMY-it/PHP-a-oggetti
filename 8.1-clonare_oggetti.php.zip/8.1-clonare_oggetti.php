<!--

	PHP a oggetti
	Clonazione

	Disponibile su devACADEMY.it

-->

<?php

	class Autore
	{
		public $nome;
		public $cognome;

		function __construct($n, $c)
		{
			$this->nome=$n;
			$this->cognome=$c;
		}


	}

	$a1=new Autore("Alessandro", "Manzoni");

	$a2= clone $a1;

	var_dump($a1);
	var_dump($a2);

	if ($a1==$a2)
		echo '$a1 e $a2 sono uguali <br>';
	else
		echo '$a1 e $a2 NON sono uguali <br>';
	if ($a1===$a2)
		echo '$a1 e $a2 sono identici <br>';
	else
		echo '$a1 e $a2 NON sono identici <br>';

?>