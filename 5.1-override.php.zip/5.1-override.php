<!--

	PHP a oggetti
	Overriding

	Disponibile su devACADEMY.it

-->

<?php

	class Persona
	{
		public $nome;
		public $cognome;

		function stampa()
		{
			return "*Mi chiamo $this->nome $this->cognome";
		}

	}

	class Studente extends Persona
	{
		public $facolta;

		function stampa()
		{
			return parent::stampa()." e studio $this->facolta";
		}
	}

	$studente=new Studente();
	$studente->nome="Stefano";
	$studente->cognome="Bianchi";
	$studente->facolta="medicina";

	var_dump($studente);

	echo $studente->stampa();

?>