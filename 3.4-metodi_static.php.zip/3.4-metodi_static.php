<!--

	PHP a oggetti
	Metodi static

	Disponibile su devACADEMY.it

-->

<?php

	class Convertitore
	{
		private static $tassoEU_USD=1.10;

		static function daEuroInDollari($euro)
		{
			return $euro*self::$tassoEU_USD." dollari USA";
		}
	}

	echo Convertitore::daEuroInDollari(100);

?>