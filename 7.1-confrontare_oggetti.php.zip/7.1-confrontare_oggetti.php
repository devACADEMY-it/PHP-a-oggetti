<!--

	PHP a oggetti
	Confrontare oggetti

	Disponibile su devACADEMY.it

-->

<?php
	class Autore
	{
		public $nome;
		public $cognome;

		function __construct($n, $c)
		{
			$this->nome=$n;
			$this->cognome=$c;
		}
	}

	$a1=new Autore("Alessandro", "Manzoni");
	$a2=new Autore("Alberto", "Moravia");
	$a3=new Autore("Alessandro", "Manzoni");

	if ($a1==$a2)
		echo '$a1 e $a2 sono uguali <br>';
	else
		echo '$a1 e $a2 NON sono uguali <br>';
	if ($a1===$a2)
		echo '$a1 e $a2 sono identici <br>';
	else
		echo '$a1 e $a2 NON sono identici <br>';


	if ($a1==$a3)
		echo '$a1 e $a3 sono uguali <br>';
	else
		echo '$a1 e $a3 NON sono uguali <br>';
	if ($a1===$a3)
		echo '$a1 e $a3 sono identici <br>';
	else
		echo '$a1 e $a3 NON sono identici <br>';

	$copia_a1=$a1;

	if ($a1===$copia_a1)
		echo '$a1 e $copia_a1 sono identici <br>';
	else
		echo '$a1 e $copia_a1 NON sono identici <br>';

?>