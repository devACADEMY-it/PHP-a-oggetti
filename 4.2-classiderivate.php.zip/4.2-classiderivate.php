<!--

	PHP a oggetti
	Classi derivate

	Disponibile su devACADEMY.it

-->

<?php
	class Persona
	{
		public $nome;
		public $cognome;

		function stampaNome()
		{
			echo "Mi chiamo $this->nome $this->cognome";
		}
	}

	class Studente extends Persona
	{
		public $facolta;
	}

	$studente=new Studente();
	$studente->nome="Stefano";
	$studente->cognome="Bianchi";
	$studente->facolta="medicina";

	var_dump($studente);

	$studente->stampaNome();

?>