<!--

	PHP a oggetti
	Visiblità protected

	Disponibile su devACADEMY.it

-->

<?php
	class Persona
	{
		protected $nome;
		protected $cognome;

		protected function __construct($n, $c)
		{
			$this->nome=$n;
			$this->cognome=$c;
		}
	}

	class Studente extends Persona
	{
		public $facolta;

		function __construct($n, $c, $f)
		{
			parent::__construct($n, $c);
			$this->facolta=$f;
		}

	}

	//$persona=new Persona("Enzo", "Neri");
	$studente=new Studente("Stefano", "Bianchi", "medicina" );
	//$studente->nome="Stefano";
	//$studente->cognome="Bianchi";
	//$studente->facolta="medicina";


	var_dump($studente);
	//var_dump($persona);

?>