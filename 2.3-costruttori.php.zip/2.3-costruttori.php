<!--

	PHP a oggetti
	Costruttori

	Disponibile su devACADEMY.it

-->

<?php

	class Persona
	{
		public $nome;
		public $cognome;
		public $eta;

		function __construct($n, $c, $e)
		{
			echo "ORA nasce l'oggetto";
			$this->nome=$n;
			$this->cognome=$c;
			$this->eta=$e;
		}


	}

	$persona=new Persona("Nino", "Rossi", 25);

	var_dump($persona);

?>