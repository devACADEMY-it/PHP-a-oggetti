<!--

	PHP a oggetti
	Oggetti con cicli e costrutti condizionali

	Disponibile su devACADEMY.it

-->

<?php

	class Account
	{
		private $username;
		private $password;
		const PASSWORD_DEFAULT="12345";

		function __construct($u, $p=PASSWORD_DEFAULT)
		{
			$this->username=$u;
			$this->password=$p;
		}

		function getUsername()
		{
			return $this->username;
		}

		function passwordDefault()
		{
			return ($this->password==PASSWORD_DEFAULT);
		}


	}

	$utenti[]=new Account("pippo");
	$utenti[]=new Account("topolino", "segreto");
	$utenti[]=new Account("minnie");
	$utenti[]=new Account("pluto","poiu");
	$utenti[]=new Account("paperino", "ciaociao");

	foreach($utenti as $u)
		if ($u->passwordDefault())
			printf("%s %s <br>", $u->getUsername(), " --- CAMBIARE PASSWORD");
		else
			printf("%s <br>", $u->getUsername());

?>