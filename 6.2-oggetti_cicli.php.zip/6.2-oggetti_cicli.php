<!--

	PHP a oggetti
	Oggetti con cicli

	Disponibile su devACADEMY.it

-->

<?php
	class Account
	{
		private $username;
		private $password;
		const PASSWORD_DEFAULT="12345";

		function __construct($u, $p=PASSWORD_DEFAULT)
		{
			$this->username=$u;
			$this->password=$p;
		}

		function getUsername()
		{
			return $this->username;
		}

	}

	$utenti[]=new Account("pippo");
	$utenti[]=new Account("topolino", "segreto");
	$utenti[]=new Account("minnie");
	$utenti[]=new Account("pluto","poiu");
	$utenti[]=new Account("paperino", "ciaociao");

	foreach($utenti as $k => $u)
		printf("[%d] %s <br>",$k, $u->getUsername());

?>