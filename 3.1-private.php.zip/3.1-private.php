<!--

	PHP a oggetti
	Visibilità private

	Disponibile su devACADEMY.it

-->

<?php

	class Persona
	{
		private $nome;
		private $cognome;

		function __construct($c)
		{
			$this->cognome=$c;
		}

		function setNome($n)
		{
			$this->nome=$n;
		}

		function getCognome()
		{
			return $this->cognome;
		}
	}

	$persona=new Persona("Rossi");
	$persona->setNome("Ezio");

	var_dump($persona);

	echo $persona->getCognome();

?>