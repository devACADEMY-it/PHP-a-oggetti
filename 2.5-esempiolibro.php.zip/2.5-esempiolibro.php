<!--

	PHP a oggetti
	Esempio: costruiamo una classe Libro completa

	Disponibile su devACADEMY.it

-->

<?php

	class Autore
	{
		public $nome;
		public $cognome;

		function __construct($n, $c)
		{
			$this->nome=$n;
			$this->cognome=$c;
		}
	}

	class Libro
	{
		public $titolo;
		public $autore;
		public $anonimo=FALSE;
		public $collocazioni=array();

		function __construct($titolo)
		{
			$this->titolo=$titolo;
		}

		function aggiungiAutore($autore)
		{
			if (is_a($autore, 'Autore'))
			{
				$this->autore=$autore;
				$this->anonimo=FALSE;
				return TRUE;
			}
			else
				return FALSE;
		}

		function autoreAnonimo()
		{
			$this->anonimo=TRUE;
			$this->autore=NULL;
		}

		function aggiungiCollocazione($biblio, $collocazione)
		{
			if  (!empty($biblio) && !empty($collocazione))
			{
				$this->collocazioni[$biblio]=$collocazione;
				return TRUE;
			}
			else
				return FALSE;
		}

		function disponibile()
		{
			return (count($this->collocazioni)>0);
		}

	}

	$libro=new Libro("I miei pensieri");
	$libro->autoreAnonimo();
	$libro->aggiungiCollocazione("BP001", "AM2345");
	if ($libro->disponibile())
		echo "$libro->titolo disponibile";
	else
		echo "$libro->titolo NON disponibile";

	var_dump($libro);

	$autore=new Autore("Renzo", "Rossi");
	$libro->aggiungiAutore($autore);
	var_dump($libro);

?>