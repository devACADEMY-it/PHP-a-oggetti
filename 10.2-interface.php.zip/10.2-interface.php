<!--

	PHP a oggetti
	Interfacce

	Disponibile su devACADEMY.it

-->

<?php

interface Calcolabile
{
	function calcolaArea();
}

class Rettangolo implements Calcolabile
{
	private $lato1;
	private $lato2;

	function __construct($l1, $l2)
	{
		$this->lato1=$l1;
		$this->lato2=$l2;
	}

	/*function calcolaArea()
	{
		return $this->lato1*$this->lato2;
	}*/
}

$r=new Rettangolo(6,5);
//echo $r->calcolaArea();

?>