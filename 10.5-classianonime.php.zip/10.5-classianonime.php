<!--

	PHP a oggetti
	Oggetti di classe anonima

	Disponibile su devACADEMY.it

-->

<?php

class Valori
{
	public $vettore=array(5,2,18,12);

	function calcola($p)
	{
		$p->sistema($this->vettore);
	}
}

$v=new Valori();

$v->calcola(
	new class{
		function sistema($v)
		{
			echo "Somma totale: ".array_sum($v)."<br>";
		}

	}
);

$v->calcola(
	new class{
		function sistema($v)
		{
			echo "Minimo del vettore: ".min($v)."<br>";
		}

	}
);

?>