<!--

	PHP a oggetti
	Oggetti e array

	Disponibile su devACADEMY.it

-->

<?php
	class Account
	{
		private $username;
		private $password;

		function __construct($u, $p="12345")
		{
			$this->username=$u;
			$this->password=$p;
		}
	}

	$utenti[]=new Account("pippo");
	$utenti[]=new Account("topolino");
	$utenti[]=new Account("paperino");
	$utenti[]=new Account("pluto");

	var_dump($utenti[2]);

	$responsabili['amministratore']=$utenti[1];
	$responsabili['referente']=$utenti[2];

	var_dump($responsabili);

?>