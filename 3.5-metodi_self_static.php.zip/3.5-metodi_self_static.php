<!--

	PHP a oggetti
	Esempio sui metodi static

	Disponibile su devACADEMY.it

-->

<?php

	class Convertitore
	{
		private static $tassi=array('USD' => 1.11,
									'CHF' => 1.09,
									'GBP' => 0.86);

		static function converti($euro, $codice)
		{
			if (self::codiceValido($codice))
				return $euro*self::$tassi[$codice]." $codice";
			else
				return "ERROR";
		}

		private static function codiceValido($codice)
		{
			if (!empty($codice) && array_key_exists($codice, self::$tassi))
				return TRUE;
			else
				return FALSE;
		}
	}

	echo Convertitore::converti(100, 'CHF');
	echo "<br>";
	echo Convertitore::converti(100, 'GBP');
	echo "<br>";
	echo Convertitore::converti(100, 'jreigjregioregijoe');

?>