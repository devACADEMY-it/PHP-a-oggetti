<!--

	PHP a oggetti
	Clonazione approfondita

	Disponibile su devACADEMY.it

-->

<?php

	class Autore
	{
		public $nome;
		public $cognome;

		function __construct($n, $c)
		{
			$this->nome=$n;
			$this->cognome=$c;
		}


	}

	class Libro
	{
		public $autore;

		function __clone()
		{
			$this->autore=clone $this->autore;
		}


	}

	$a1=new Autore("Alessandro", "Manzoni");
	$l=new Libro();
	$l->autore=$a1;

	$l2=clone $l;

	$a1->nome="Luigi";

	var_dump($l);
	var_dump($l2);

?>